CREATE TABLE `tb_answer` (
  `inq_no` int(11) NOT NULL AUTO_INCREMENT,
  `ans_content` text,
  `ans_writer` varchar(30) DEFAULT NULL,
  `ans_regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ans_moddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ans_title` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`inq_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tb_basket` (
  `bas_no` int(11) NOT NULL AUTO_INCREMENT,
  `loginID` varchar(30) NOT NULL,
  `bas_qty` int(11) DEFAULT NULL,
  `bas_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pro_no` varchar(100) NOT NULL,
  PRIMARY KEY (`bas_no`,`pro_no`),
  KEY `fk_tb_userinfo_to_tb_basket` (`loginID`),
  KEY `fk_tb_product_to_tb_basket` (`pro_no`),
  CONSTRAINT `fk_tb_product_to_tb_basket` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_userinfo_to_tb_basket` FOREIGN KEY (`loginID`) REFERENCES `tb_userinfo` (`loginID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_delivery` (
  `deli_no` int(11) NOT NULL AUTO_INCREMENT,
  `deli_company` varchar(100) DEFAULT NULL,
  `deli_id` varchar(30) DEFAULT NULL,
  `deli_password` varchar(200) DEFAULT NULL,
  `deli_name` varchar(100) DEFAULT NULL,
  `deli_phone` varchar(20) DEFAULT NULL,
  `del_cd` varchar(20) DEFAULT 'n' COMMENT '0 : �̻��� 1: ����',
  `deli_email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`deli_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_detail_code` (
  `group_code` varchar(20) NOT NULL COMMENT '�׷��ڵ�',
  `detail_code` varchar(20) NOT NULL COMMENT '���ڵ�',
  `detail_name` varchar(200) DEFAULT NULL COMMENT '���ڵ��',
  `note` varchar(2000) DEFAULT NULL COMMENT '�ּ�',
  `use_yn` varchar(10) DEFAULT NULL COMMENT '��뿩��',
  `regId` varchar(20) DEFAULT NULL COMMENT '�����',
  `reg_date` datetime DEFAULT NULL COMMENT '�����',
  `updateId` varchar(20) DEFAULT NULL COMMENT '������',
  `update_date` datetime DEFAULT NULL COMMENT '������',
  PRIMARY KEY (`group_code`,`detail_code`),
  CONSTRAINT `fk_tb_group_code_to_tb_detail_code_1` FOREIGN KEY (`group_code`) REFERENCES `tb_group_code` (`group_code`),
  CONSTRAINT `FK_tb_group_code_TO_tb_detail_code` FOREIGN KEY (`group_code`) REFERENCES `tb_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='�����ڵ������';

CREATE TABLE `tb_direction` (
  `direction_no` int(11) NOT NULL AUTO_INCREMENT,
  `pro_no` varchar(100) NOT NULL,
  `refund_no` int(11) DEFAULT NULL,
  `purchase_no` int(11) DEFAULT NULL,
  `direction_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `direction_manager` varchar(30) DEFAULT NULL,
  `direction_in_qty` int(11) DEFAULT NULL,
  `direction_out_qty` int(11) DEFAULT NULL,
  `direction_note` text,
  `direction_cd` varchar(20) DEFAULT NULL COMMENT 'purchase : ����  refund : ��ǰ shipping : ���',
  `order_no` int(11) DEFAULT NULL,
  `ship_no` int(11) DEFAULT NULL,
  `ware_no` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`direction_no`),
  KEY `fk_tb_product_to_tb_direction` (`pro_no`),
  KEY `fk_tb_purchase_to_tb_direction` (`purchase_no`),
  KEY `fk_tb_refund_to_tb_direction` (`refund_no`),
  KEY `fk_tb_shipping_to_tb_direction` (`ship_no`),
  KEY `tb_direction_ibfk_1` (`ware_no`),
  KEY `fk_tb_order_to_tb_direction` (`order_no`),
  CONSTRAINT `fk_tb_order_to_tb_direction` FOREIGN KEY (`order_no`) REFERENCES `tb_order` (`order_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_product_to_tb_direction` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_purchase_to_tb_direction` FOREIGN KEY (`purchase_no`) REFERENCES `tb_purchase` (`purchase_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_refund_to_tb_direction` FOREIGN KEY (`refund_no`) REFERENCES `tb_refund` (`refund_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_shipping_to_tb_direction` FOREIGN KEY (`ship_no`) REFERENCES `tb_shipping` (`ship_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_file` (
  `file_no` int(11) NOT NULL AUTO_INCREMENT,
  `file_server_path` varchar(200) DEFAULT NULL,
  `file_local_path` varchar(200) DEFAULT NULL,
  `file_new_name` varchar(200) DEFAULT NULL,
  `file_ofname` varchar(200) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `pro_no` varchar(100) DEFAULT NULL,
  `notice_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`file_no`),
  KEY `fk_tb_product_to_tb_file` (`pro_no`),
  KEY `tb_file_notice_no_fk` (`notice_no`),
  CONSTRAINT `fk_tb_product_to_tb_file` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `tb_file_notice_no_fk` FOREIGN KEY (`notice_no`) REFERENCES `tb_notice` (`notice_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_group_code` (
  `group_code` varchar(20) NOT NULL COMMENT '�׷��ڵ�',
  `group_name` varchar(200) DEFAULT NULL COMMENT '�׷��ڵ��',
  `note` varchar(2000) DEFAULT NULL COMMENT '�ּ�',
  `use_yn` varchar(10) DEFAULT NULL COMMENT '��뿩��',
  `regId` varchar(20) DEFAULT NULL COMMENT '�����',
  `reg_date` datetime DEFAULT NULL COMMENT '�����',
  `updateId` varchar(20) DEFAULT NULL COMMENT '������',
  `update_date` datetime DEFAULT NULL COMMENT '������',
  PRIMARY KEY (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='�����ڵ�';

CREATE TABLE `tb_inquiry` (
  `inq_no` int(11) NOT NULL AUTO_INCREMENT,
  `inq_title` varchar(200) DEFAULT NULL,
  `inq_content` text,
  `inq_regdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `inq_moddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `category_cd` varchar(20) DEFAULT NULL COMMENT 'ī�װ���',
  `answer_cd` varchar(20) DEFAULT NULL COMMENT '0 : �̴亯\n1 : �亯�Ϸ�\n-1 : ����',
  `loginID` varchar(30) NOT NULL,
  PRIMARY KEY (`inq_no`),
  KEY `fk_tb_userinfo_to_tb_inquiry` (`loginID`),
  CONSTRAINT `fk_tb_userinfo_to_tb_inquiry` FOREIGN KEY (`loginID`) REFERENCES `tb_userinfo` (`loginID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tb_notice` (
  `notice_no` int(11) NOT NULL AUTO_INCREMENT,
  `notice_title` varchar(200) DEFAULT NULL,
  `notice_content` text,
  `notice_hit` int(11) DEFAULT NULL,
  `notice_regdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `notice_moddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `loginID` varchar(30) NOT NULL,
  `del_cd` varchar(20) DEFAULT 'n',
  PRIMARY KEY (`notice_no`),
  KEY `fk_tb_userinfo_to_tb_notice` (`loginID`),
  CONSTRAINT `fk_tb_userinfo_to_tb_notice` FOREIGN KEY (`loginID`) REFERENCES `tb_userinfo` (`loginID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_order` (
  `order_no` int(11) NOT NULL AUTO_INCREMENT,
  `pro_no` varchar(100) NOT NULL,
  `order_qty` int(11) DEFAULT NULL,
  `order_cd` varchar(20) DEFAULT NULL COMMENT '0 : �ֹ�\n1 : ��ǰ',
  `deposit_cd` varchar(20) DEFAULT NULL COMMENT '0: �Ա�Ȯ��\n1 : ���Ա�',
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `order_expdate` timestamp NULL DEFAULT NULL,
  `order_mod_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `loginID` varchar(30) NOT NULL,
  PRIMARY KEY (`order_no`,`pro_no`),
  KEY `fk_tb_product_to_tb_order` (`pro_no`),
  CONSTRAINT `fk_tb_product_to_tb_order` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_product` (
  `pro_no` varchar(100) NOT NULL,
  `pro_name` varchar(100) DEFAULT NULL,
  `pro_deli_price` int(11) DEFAULT NULL,
  `pro_model_name` varchar(100) DEFAULT NULL,
  `pro_manu_name` varchar(100) DEFAULT NULL,
  `pro_price` int(11) DEFAULT NULL,
  `pro_detail` text,
  `pro_cd` varchar(20) DEFAULT NULL,
  `pro_regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deli_no` int(11) NOT NULL,
  PRIMARY KEY (`pro_no`),
  KEY `fk_product_delivery` (`deli_no`),
  CONSTRAINT `fk_product_delivery` FOREIGN KEY (`deli_no`) REFERENCES `tb_delivery` (`deli_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tb_product_io_warehouse` (
  `pro_io_no` int(11) NOT NULL AUTO_INCREMENT,
  `pro_io_qty` int(11) DEFAULT NULL,
  `pro_io_cd` varchar(20) DEFAULT NULL COMMENT '0 : �԰�\n1 : ���',
  `pro_io_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pro_io_memo` text,
  `pro_no` varchar(100) DEFAULT NULL,
  `refund_no` int(11) DEFAULT NULL,
  `purchase_no` int(11) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  `ware_no` int(11) DEFAULT NULL,
  PRIMARY KEY (`pro_io_no`),
  KEY `fk_tb_purchase_to_tb_product_io_warehouse` (`purchase_no`),
  KEY `fk_tb_product_to_tb_product_io_warehouse` (`pro_no`),
  KEY `fk_tb_refund_to_tb_product_io_warehouse` (`refund_no`),
  KEY `fk_tb_order_to_tb_product_io_warehouse` (`order_no`),
  KEY `fk_tb_warehouse_to_tb_product_io_warehouse` (`ware_no`),
  CONSTRAINT `fk_tb_warehouse_to_tb_product_io_warehouse` FOREIGN KEY (`ware_no`) REFERENCES `tb_warehouse` (`ware_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_order_to_tb_product_io_warehouse` FOREIGN KEY (`order_no`) REFERENCES `tb_order` (`order_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_product_to_tb_product_io_warehouse` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_purchase_to_tb_product_io_warehouse` FOREIGN KEY (`purchase_no`) REFERENCES `tb_purchase` (`purchase_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_refund_to_tb_product_io_warehouse` FOREIGN KEY (`refund_no`) REFERENCES `tb_refund` (`refund_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_product_warehouse` (
  `pro_no` varchar(100) NOT NULL DEFAULT '',
  `pro_ware_qty` int(11) DEFAULT '0',
  `ware_no` int(11) NOT NULL,
  PRIMARY KEY (`pro_no`,`ware_no`),
  KEY `productwarehouse_warehouse` (`ware_no`),
  CONSTRAINT `fk_tb_product_to_tb_product_warehouse` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `productwarehouse_warehouse` FOREIGN KEY (`ware_no`) REFERENCES `tb_warehouse` (`ware_no`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `tb_purchase` (
  `purchase_no` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_qty` int(11) DEFAULT NULL,
  `purchase_cd` varchar(20) DEFAULT NULL COMMENT '0 : �̽��� 1 : ���� 2 : ��ǰ',
  `purchase_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `pro_no` varchar(100) NOT NULL,
  `loginID` varchar(30) NOT NULL,
  `ware_no` int(11) NOT NULL,
  PRIMARY KEY (`purchase_no`,`ware_no`),
  KEY `fk_tb_refund_to_tb_purchase` (`loginID`),
  KEY `fk_tb_product_to_tb_purchase` (`pro_no`),
  KEY `fk_tb_warehouse_to_tb_purchase` (`ware_no`),
  CONSTRAINT `fk_tb_warehouse_to_tb_purchase` FOREIGN KEY (`ware_no`) REFERENCES `tb_warehouse` (`ware_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_product_to_tb_purchase` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_refund_to_tb_purchase` FOREIGN KEY (`loginID`) REFERENCES `tb_userinfo` (`loginID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_refund` (
  `refund_no` int(11) NOT NULL AUTO_INCREMENT,
  `refund_qty` int(11) DEFAULT NULL,
  `refund_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `refund_cd` varchar(20) DEFAULT NULL COMMENT '0 : ������\n1 : ����',
  `refund_confirm_cd` varchar(20) DEFAULT NULL COMMENT '0 : ��Ȯ��\n1 : Ȯ��',
  `refund_note` text,
  `purchase_no` int(11) DEFAULT NULL,
  `pro_no` varchar(100) NOT NULL,
  `order_no` int(11) DEFAULT NULL,
  `ware_no` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`refund_no`,`pro_no`,`ware_no`),
  KEY `fk_tb_product_to_tb_refund` (`pro_no`),
  KEY `fk_tb_purchase_to_tb_refund` (`purchase_no`),
  KEY `fk_tb_order_to_tb_refund` (`order_no`),
  KEY `fk_tb_warehouse_to_tb_refund` (`ware_no`),
  CONSTRAINT `fk_tb_warehouse_to_tb_refund` FOREIGN KEY (`ware_no`) REFERENCES `tb_warehouse` (`ware_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_order_to_tb_refund` FOREIGN KEY (`order_no`) REFERENCES `tb_order` (`order_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_product_to_tb_refund` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_purchase_to_tb_refund` FOREIGN KEY (`purchase_no`) REFERENCES `tb_purchase` (`purchase_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_shipping` (
  `ship_no` int(11) NOT NULL AUTO_INCREMENT,
  `ship_cd` varchar(20) DEFAULT NULL,
  `ship_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `ship_manager` varchar(100) DEFAULT NULL,
  `pro_no` varchar(100) NOT NULL,
  `refund_no` int(11) DEFAULT NULL,
  `order_no` int(11) DEFAULT NULL,
  `ship_qty` int(11) DEFAULT NULL,
  `ware_no` int(11) NOT NULL,
  PRIMARY KEY (`ship_no`,`ware_no`),
  KEY `fk_tb_product_to_tb_shipping` (`pro_no`),
  KEY `fk_tb_refund_to_tb_shipping` (`refund_no`),
  KEY `fk_tb_order_to_tb_shipping` (`order_no`),
  KEY `fk_tb_warehouse_to_tb_shipping` (`ware_no`),
  CONSTRAINT `fk_tb_warehouse_to_tb_shipping` FOREIGN KEY (`ware_no`) REFERENCES `tb_warehouse` (`ware_no`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tb_order_to_tb_shipping` FOREIGN KEY (`order_no`) REFERENCES `tb_order` (`order_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_product_to_tb_shipping` FOREIGN KEY (`pro_no`) REFERENCES `tb_product` (`pro_no`) ON DELETE CASCADE,
  CONSTRAINT `fk_tb_refund_to_tb_shipping` FOREIGN KEY (`refund_no`) REFERENCES `tb_refund` (`refund_no`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

CREATE TABLE `tb_userinfo` (
  `loginID` varchar(20) NOT NULL COMMENT '���̵�',
  `user_type` varchar(20) DEFAULT NULL COMMENT '�����_0, ������_1	 		 	',
  `name` varchar(100) DEFAULT NULL COMMENT '�̸�',
  `password` varchar(100) DEFAULT NULL COMMENT '��й�ȣ',
  `gender_cd` varchar(20) DEFAULT NULL COMMENT '����',
  `user_tel1` varchar(4) DEFAULT NULL COMMENT '����ó1',
  `user_tel2` varchar(4) DEFAULT NULL COMMENT '����ó2',
  `user_tel3` varchar(4) DEFAULT NULL COMMENT '����ó3',
  `user_zipcode` varchar(50) DEFAULT NULL COMMENT '�ּ�',
  `user_address` varchar(50) DEFAULT NULL,
  `user_dt_address` varchar(50) DEFAULT NULL,
  `user_account` varchar(100) DEFAULT NULL,
  `bank_cd` varchar(20) DEFAULT NULL,
  `div_cd` varchar(20) DEFAULT NULL,
  `del_cd` varchar(20) DEFAULT NULL,
  `user_email` varchar(50) NOT NULL,
  `user_company` varchar(100) DEFAULT NULL,
  `approval_cd` varchar(20) DEFAULT NULL,
  `user_regdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`loginID`),
  UNIQUE KEY `user_email_UNIQUE` (`user_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='���������';

CREATE TABLE `tb_warehouse` (
  `ware_no` int(11) NOT NULL AUTO_INCREMENT,
  `ware_cd` varchar(20) DEFAULT NULL,
  `ware_name` varchar(100) DEFAULT NULL,
  `ware_address` varchar(50) DEFAULT NULL,
  `ware_dt_address` varchar(50) DEFAULT NULL,
  `ware_zipcode` varchar(50) DEFAULT NULL,
  `del_cd` varchar(20) DEFAULT '0',
  `loginID` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`ware_no`),
  KEY `warehouse_userinfo` (`loginID`),
  CONSTRAINT `warehouse_userinfo` FOREIGN KEY (`loginID`) REFERENCES `tb_userinfo` (`loginID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

CREATE TABLE `tm_mnu_mst` (
  `MNU_ID` varchar(5) NOT NULL COMMENT '�޴�ID',
  `HIR_MNU_ID` varchar(5) DEFAULT NULL COMMENT '���� �޴� ID',
  `MNU_NM` varchar(100) DEFAULT NULL COMMENT '�޴� ��',
  `MNU_URL` varchar(500) DEFAULT NULL COMMENT '�޴� URL',
  `MNU_DVS_COD` varchar(1) DEFAULT NULL COMMENT '�޴� ���� �ڵ�rn* M : ������rn* U : �����',
  `GRP_NUM` int(11) DEFAULT NULL COMMENT '�׷� ��ȣ',
  `ODR` int(11) DEFAULT NULL COMMENT '����',
  `LVL` smallint(6) DEFAULT NULL COMMENT '����',
  `MNU_ICO_COD` varchar(7) DEFAULT NULL COMMENT '�޴� ������ �ڵ�',
  `USE_POA` varchar(1) DEFAULT NULL COMMENT '��� ����',
  `DLT_POA` varchar(1) DEFAULT NULL COMMENT '���� ����',
  PRIMARY KEY (`MNU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='�޴�������';

CREATE TABLE `tn_usr_mnu_atrt` (
  `MNU_ID` varchar(5) NOT NULL COMMENT '�޴� ID',
  `user_type` varchar(20) DEFAULT NULL COMMENT '�����Ÿ��',
  PRIMARY KEY (`MNU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='����ں��޴�';

